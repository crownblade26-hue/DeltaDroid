package com.example.deltadroid

import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import java.io.File

// libretro joypad ids
const val KEY_B = 0
const val KEY_SELECT = 2
const val KEY_START = 3
const val KEY_UP = 4
const val KEY_DOWN = 5
const val KEY_LEFT = 6
const val KEY_RIGHT = 7
const val KEY_A = 8
const val KEY_L = 10
const val KEY_R = 11

class MainActivity : ComponentActivity() {
    private val runner = EmuRunner()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { App(runner) } }
    }

    override fun onPause() {
        super.onPause()
        runner.paused = true
        Native.flushSave()
    }

    override fun onResume() {
        super.onResume()
        runner.paused = false
    }

    override fun onDestroy() {
        runner.stop()
        super.onDestroy()
    }
}

fun copyRom(ctx: Context, uri: Uri): String {
    var name = "game.gba"
    ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
        if (c.moveToFirst()) {
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (i >= 0) name = c.getString(i)
        }
    }
    val out = File(ctx.filesDir, name)
    ctx.contentResolver.openInputStream(uri)!!.use { input ->
        out.outputStream().use { input.copyTo(it) }
    }
    return out.absolutePath
}

@Composable
fun App(runner: EmuRunner) {
    val ctx = LocalContext.current
    var romPath by remember { mutableStateOf<String?>(null) }
    var system by remember { mutableStateOf<GameSystem?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val p = copyRom(ctx, uri)
            val s = systemFor(p)
            if (s == null) {
                Toast.makeText(ctx, "Unsupported file type (use unzipped ROMs)", Toast.LENGTH_LONG).show()
            } else {
                system = s
                romPath = p
            }
        }
    }
    val path = romPath
    val sys = system
    if (path == null || sys == null) {
        Column(
            Modifier.fillMaxSize().background(Color(0xFF1B1B2F)),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("DeltaDroid", fontSize = 32.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Spacer(Modifier.height(8.dp))
            Text("GBA  GBC  NES  SNES  Genesis", color = Color.LightGray, fontSize = 13.sp)
            Spacer(Modifier.height(24.dp))
            Button(onClick = { picker.launch(arrayOf("*/*")) }) { Text("Open game") }
        }
    } else {
        GameScreen(runner, path, sys) { romPath = null }
    }
}

@Composable
fun GameScreen(runner: EmuRunner, romPath: String, sys: GameSystem, onExit: () -> Unit) {
    val ctx = LocalContext.current
    DisposableEffect(romPath) {
        if (!runner.start(ctx, romPath, sys.core)) {
            Toast.makeText(ctx, "Could not start game", Toast.LENGTH_LONG).show()
            onExit()
        }
        onDispose { runner.stop() }
    }
    val statePath = "$romPath.state"
    Column(
        Modifier.fillMaxSize().background(Color(0xFF3A2E7A)).padding(top = 32.dp, start = 8.dp, end = 8.dp, bottom = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.fillMaxWidth().aspectRatio(sys.aspect).background(Color.Black)) {
            AndroidView(
                factory = { c ->
                    SurfaceView(c).apply {
                        holder.addCallback(object : SurfaceHolder.Callback {
                            override fun surfaceCreated(h: SurfaceHolder) { Native.setSurface(h.surface) }
                            override fun surfaceChanged(h: SurfaceHolder, f: Int, w: Int, ht: Int) {}
                            override fun surfaceDestroyed(h: SurfaceHolder) { Native.setSurface(null) }
                        })
                    }
                },
                modifier = Modifier.fillMaxSize()
            )
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            TextButton(onClick = { Native.stateOp(statePath, false) }) { Text("Save state", color = Color.White) }
            TextButton(onClick = { Native.stateOp(statePath, true) }) { Text("Load state", color = Color.White) }
            TextButton(onClick = onExit) { Text("Exit", color = Color.White) }
        }
        Spacer(Modifier.weight(1f))
        if (sys.shoulders) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                PadKey("L", KEY_L, Modifier.width(110.dp).height(44.dp))
                PadKey("R", KEY_R, Modifier.width(110.dp).height(44.dp))
            }
            Spacer(Modifier.height(16.dp))
        }
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            DPad()
            FaceButtons(sys)
        }
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(24.dp)) {
            if (sys.hasSelect) PadKey("SELECT", KEY_SELECT, Modifier.width(84.dp).height(32.dp), RoundedCornerShape(16.dp))
            PadKey("START", KEY_START, Modifier.width(84.dp).height(32.dp), RoundedCornerShape(16.dp))
        }
        Spacer(Modifier.weight(1f))
    }
}

@Composable
fun FaceButtons(sys: GameSystem) {
    Box(Modifier.size(width = 170.dp, height = 130.dp)) {
        when (sys.faces) {
            Faces.TWO -> {
                PadKey("B", KEY_B, Modifier.size(64.dp).align(Alignment.BottomStart), CircleShape)
                PadKey("A", KEY_A, Modifier.size(64.dp).align(Alignment.TopEnd), CircleShape)
            }
            Faces.FOUR -> {
                PadKey("X", 9, Modifier.size(52.dp).align(Alignment.TopCenter), CircleShape)
                PadKey("B", KEY_B, Modifier.size(52.dp).align(Alignment.BottomCenter), CircleShape)
                PadKey("Y", 1, Modifier.size(52.dp).align(Alignment.CenterStart), CircleShape)
                PadKey("A", KEY_A, Modifier.size(52.dp).align(Alignment.CenterEnd), CircleShape)
            }
            Faces.GENESIS -> {
                Row(Modifier.align(Alignment.Center), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PadKey("A", 1, Modifier.size(52.dp), CircleShape)   // libretro Y -> MD A
                    PadKey("B", KEY_B, Modifier.size(52.dp), CircleShape)
                    PadKey("C", KEY_A, Modifier.size(52.dp), CircleShape) // libretro A -> MD C
                }
            }
        }
    }
}

@Composable
fun DPad() {
    val s = 56.dp
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        PadKey("\u25B2", KEY_UP, Modifier.size(s))
        Row {
            PadKey("\u25C0", KEY_LEFT, Modifier.size(s))
            Spacer(Modifier.size(s))
            PadKey("\u25B6", KEY_RIGHT, Modifier.size(s))
        }
        PadKey("\u25BC", KEY_DOWN, Modifier.size(s))
    }
}

@Composable
fun PadKey(label: String, id: Int, modifier: Modifier = Modifier, shape: Shape = RoundedCornerShape(12.dp)) {
    var down by remember { mutableStateOf(false) }
    Box(
        modifier
            .clip(shape)
            .background(if (down) Color(0xFFB0A8FF) else Color(0xFF1E1E2E))
            .pointerInput(id) {
                awaitEachGesture {
                    awaitFirstDown()
                    down = true
                    Native.setKey(id, true)
                    waitForUpOrCancellation()
                    down = false
                    Native.setKey(id, false)
                }
            },
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
    }
}
