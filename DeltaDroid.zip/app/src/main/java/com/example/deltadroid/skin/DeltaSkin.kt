package com.example.deltadroid.skin

import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.zip.ZipFile

data class Rect(val x: Float, val y: Float, val w: Float, val h: Float)
data class Edges(val top: Float = 0f, val bottom: Float = 0f, val left: Float = 0f, val right: Float = 0f)

data class SkinItem(
    val inputs: List<String>,      // e.g. ["a"], ["dpad"] or thumbstick axes
    val frame: Rect,
    val edges: Edges
)

data class SkinScreen(val output: Rect, val input: Rect?)

data class SkinLayout(
    val mappingW: Float,
    val mappingH: Float,
    val assetName: String?,        // image/pdf in the zip drawn behind the buttons
    val items: List<SkinItem>,
    val screens: List<SkinScreen>
)

class DeltaSkin(
    val name: String,
    val identifier: String,
    val gameType: String,          // e.g. com.rileytestut.delta.game.gba
    private val reps: JSONObject,
    private val zip: File
) {
    /** device: "iphone"/"ipad"; display: "standard"/"edgeToEdge"; orientation: "portrait"/"landscape" */
    fun layout(device: String = "iphone", display: String = "edgeToEdge", orientation: String = "portrait"): SkinLayout? {
        val d = reps.optJSONObject(device) ?: return null
        val o = (d.optJSONObject(display) ?: d.optJSONObject("standard"))?.optJSONObject(orientation) ?: return null
        val size = o.getJSONObject("mappingSize")
        val asset = o.optJSONObject("assets")?.let { it.optString("resizable").ifEmpty { it.optString("large") } }

        val items = mutableListOf<SkinItem>()
        o.optJSONArray("items")?.forEachObj { it ->
            val inputsAny = it.get("inputs")
            val inputs = if (inputsAny is JSONArray) inputsAny.strings()
            else listOf((inputsAny as JSONObject).let { j -> j.keys().asSequence().map { k -> j.getString(k) }.joinToString(",") })
            items += SkinItem(inputs, it.getJSONObject("frame").rect(), it.optJSONObject("extendedEdges").edges())
        }
        val screens = mutableListOf<SkinScreen>()
        o.optJSONArray("screens")?.forEachObj {
            screens += SkinScreen(it.getJSONObject("outputFrame").rect(), it.optJSONObject("inputFrame")?.rect())
        }
        return SkinLayout(size.getInt("width").toFloat(), size.getInt("height").toFloat(), asset, items, screens)
    }

    fun readAsset(name: String): ByteArray? = ZipFile(zip).use { z ->
        z.getEntry(name)?.let { z.getInputStream(it).readBytes() }
    }

    companion object {
        fun load(file: File): DeltaSkin {
            val json = ZipFile(file).use { z ->
                String(z.getInputStream(z.getEntry("info.json")).readBytes())
            }
            val r = JSONObject(json)
            return DeltaSkin(
                r.getString("name"), r.getString("identifier"),
                r.getString("gameTypeIdentifier"), r.getJSONObject("representations"), file
            )
        }
    }
}

private fun JSONObject.rect() = Rect(
    getDouble("x").toFloat(), getDouble("y").toFloat(),
    getDouble("width").toFloat(), getDouble("height").toFloat()
)

private fun JSONObject?.edges() = if (this == null) Edges() else Edges(
    optDouble("top", 0.0).toFloat(), optDouble("bottom", 0.0).toFloat(),
    optDouble("left", 0.0).toFloat(), optDouble("right", 0.0).toFloat()
)

private fun JSONArray.strings() = (0 until length()).map { getString(it) }
private inline fun JSONArray.forEachObj(f: (JSONObject) -> Unit) {
    for (i in 0 until length()) f(getJSONObject(i))
}
