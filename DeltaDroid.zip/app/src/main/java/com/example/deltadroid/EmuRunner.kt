package com.example.deltadroid

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack

class EmuRunner {
    @Volatile var paused = false
    @Volatile private var running = false
    private var thread: Thread? = null

    fun start(ctx: Context, romPath: String, coreName: String): Boolean {
        val core = ctx.applicationInfo.nativeLibraryDir + "/" + coreName
        if (!Native.start(core, romPath, ctx.filesDir.absolutePath)) return false
        running = true
        thread = Thread {
            val rate = Native.sampleRate()
            val minBuf = AudioTrack.getMinBufferSize(
                rate, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT
            )
            val track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setSampleRate(rate)
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                        .build()
                )
                .setBufferSizeInBytes(minBuf * 2)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
            track.play()
            val buf = ShortArray(8192)
            while (running) {
                if (paused) {
                    Native.idle()
                    Thread.sleep(30)
                    continue
                }
                Native.run()
                val n = Native.audioDrain(buf)
                if (n > 0) track.write(buf, 0, n)
            }
            track.stop()
            track.release()
            Native.stop()
        }.also { it.start() }
        return true
    }

    fun stop() {
        running = false
        thread?.join()
        thread = null
    }
}
