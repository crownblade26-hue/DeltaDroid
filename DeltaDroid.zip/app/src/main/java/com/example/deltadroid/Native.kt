package com.example.deltadroid

import android.view.Surface

object Native {
    init { System.loadLibrary("emu") }
    external fun start(core: String, rom: String, saveDir: String): Boolean
    external fun run()
    external fun idle()
    external fun stop()
    external fun setSurface(surface: Surface?)
    external fun setKey(id: Int, down: Boolean)
    external fun audioDrain(buf: ShortArray): Int
    external fun sampleRate(): Int
    external fun stateOp(path: String, load: Boolean)
    external fun flushSave()
}
