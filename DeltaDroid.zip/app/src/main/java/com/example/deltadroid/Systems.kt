package com.example.deltadroid

enum class Faces { TWO, FOUR, GENESIS }

data class GameSystem(
    val name: String,
    val core: String,          // file name inside the app's native lib dir
    val aspect: Float,
    val shoulders: Boolean,
    val faces: Faces,
    val hasSelect: Boolean = true
)

private val GBA = GameSystem("GBA", "libcore_mgba.so", 240f / 160f, true, Faces.TWO)
private val GBC = GameSystem("GB/GBC", "libcore_gambatte.so", 160f / 144f, false, Faces.TWO)
private val NES = GameSystem("NES", "libcore_fceumm.so", 4f / 3f, false, Faces.TWO)
private val SNES = GameSystem("SNES", "libcore_snes9x.so", 4f / 3f, true, Faces.FOUR)
private val GEN = GameSystem("Genesis", "libcore_gpgx.so", 4f / 3f, false, Faces.GENESIS, hasSelect = false)

fun systemFor(fileName: String): GameSystem? = when (fileName.substringAfterLast('.').lowercase()) {
    "gba" -> GBA
    "gb", "gbc" -> GBC
    "nes" -> NES
    "smc", "sfc" -> SNES
    "md", "gen", "smd", "bin" -> GEN
    else -> null
}
