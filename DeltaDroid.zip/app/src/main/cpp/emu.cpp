// Minimal libretro frontend for Android (video -> ANativeWindow, audio/input via JNI)
#include <jni.h>
#include <dlfcn.h>
#include <android/log.h>
#include <android/native_window.h>
#include <android/native_window_jni.h>
#include <atomic>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <mutex>
#include <string>
#include <vector>

#define LOG(...) __android_log_print(ANDROID_LOG_INFO, "DeltaDroid", __VA_ARGS__)

struct retro_game_info { const char *path; const void *data; size_t size; const char *meta; };
struct retro_game_geometry { unsigned base_width, base_height, max_width, max_height; float aspect_ratio; };
struct retro_system_timing { double fps; double sample_rate; };
struct retro_system_av_info { retro_game_geometry geometry; retro_system_timing timing; };

typedef bool (*env_t)(unsigned, void *);
typedef void (*video_t)(const void *, unsigned, unsigned, size_t);
typedef void (*audio_t)(int16_t, int16_t);
typedef size_t (*audio_batch_t)(const int16_t *, size_t);
typedef void (*poll_t)(void);
typedef int16_t (*input_t)(unsigned, unsigned, unsigned, unsigned);

static void *core = nullptr;
static void (*r_set_environment)(env_t);
static void (*r_set_video_refresh)(video_t);
static void (*r_set_audio_sample)(audio_t);
static void (*r_set_audio_sample_batch)(audio_batch_t);
static void (*r_set_input_poll)(poll_t);
static void (*r_set_input_state)(input_t);
static void (*r_init)(void);
static void (*r_deinit)(void);
static void (*r_get_av_info)(retro_system_av_info *);
static bool (*r_load_game)(const retro_game_info *);
static void (*r_unload_game)(void);
static void (*r_run)(void);
static size_t (*r_serialize_size)(void);
static bool (*r_serialize)(void *, size_t);
static bool (*r_unserialize)(const void *, size_t);
static void *(*r_mem_data)(unsigned);
static size_t (*r_mem_size)(unsigned);
#define LOAD(v, s) *(void **)(&v) = dlsym(core, s)

static std::string g_saveDir, g_sramPath;
static std::vector<uint8_t> g_rom;
static double g_sampleRate = 32768;
static int g_fmt = 1; // 1 = XRGB8888, 2 = RGB565

static std::mutex g_winMutex;
static ANativeWindow *g_win = nullptr;
static int g_w = 0, g_h = 0;

static std::mutex g_audMutex;
static std::vector<int16_t> g_aud;

static std::atomic<uint32_t> g_keys{0};
static std::atomic<bool> g_flush{false};
static std::atomic<int> g_op{0};
static std::mutex g_opMutex;
static std::string g_opPath;

static bool environment(unsigned cmd, void *data) {
    switch (cmd) {
        case 3: *(bool *)data = true; return true;                       // GET_CAN_DUPE
        case 10: { int f = *(int *)data; if (f == 1 || f == 2) { g_fmt = f; return true; } return false; } // SET_PIXEL_FORMAT
        case 9: case 31: *(const char **)data = g_saveDir.c_str(); return true; // system / save dir
        case 52: *(unsigned *)data = 0; return true;                     // GET_CORE_OPTIONS_VERSION
        default: return false;
    }
}

static void video_refresh(const void *data, unsigned w, unsigned h, size_t pitch) {
    if (!data) return;
    std::lock_guard<std::mutex> l(g_winMutex);
    if (!g_win) return;
    if ((int)w != g_w || (int)h != g_h) {
        ANativeWindow_setBuffersGeometry(g_win, w, h, WINDOW_FORMAT_RGBA_8888);
        g_w = w; g_h = h;
    }
    ANativeWindow_Buffer buf;
    if (ANativeWindow_lock(g_win, &buf, nullptr) != 0) return;
    unsigned rows = h < (unsigned)buf.height ? h : (unsigned)buf.height;
    for (unsigned y = 0; y < rows; y++) {
        uint32_t *dst = (uint32_t *)buf.bits + (size_t)y * buf.stride;
        if (g_fmt == 2) {
            const uint16_t *src = (const uint16_t *)((const uint8_t *)data + y * pitch);
            for (unsigned x = 0; x < w; x++) {
                uint32_t p = src[x];
                uint32_t r = ((p >> 11) & 31) * 255 / 31, g = ((p >> 5) & 63) * 255 / 63, b = (p & 31) * 255 / 31;
                dst[x] = 0xFF000000u | (b << 16) | (g << 8) | r;
            }
        } else {
            const uint32_t *src = (const uint32_t *)((const uint8_t *)data + y * pitch);
            for (unsigned x = 0; x < w; x++) {
                uint32_t p = src[x];
                dst[x] = 0xFF000000u | ((p & 0xFF) << 16) | (p & 0xFF00) | ((p >> 16) & 0xFF);
            }
        }
    }
    ANativeWindow_unlockAndPost(g_win);
}

static void push_audio(const int16_t *d, size_t frames) {
    std::lock_guard<std::mutex> l(g_audMutex);
    g_aud.insert(g_aud.end(), d, d + frames * 2);
    if (g_aud.size() > 16384) g_aud.erase(g_aud.begin(), g_aud.end() - 16384);
}
static void audio_sample(int16_t l, int16_t r) { int16_t s[2] = {l, r}; push_audio(s, 1); }
static size_t audio_batch(const int16_t *d, size_t frames) { push_audio(d, frames); return frames; }
static void input_poll() {}
static int16_t input_state(unsigned port, unsigned device, unsigned, unsigned id) {
    if (port != 0 || device != 1 || id > 15) return 0;
    return (g_keys.load() >> id) & 1;
}

static void saveSram() {
    if (!r_mem_data || g_sramPath.empty()) return;
    void *p = r_mem_data(0); size_t n = r_mem_size(0);
    if (!p || !n) return;
    FILE *f = fopen(g_sramPath.c_str(), "wb");
    if (f) { fwrite(p, 1, n, f); fclose(f); }
}
static void loadSram() {
    void *p = r_mem_data(0); size_t n = r_mem_size(0);
    if (!p || !n) return;
    FILE *f = fopen(g_sramPath.c_str(), "rb");
    if (f) { fread(p, 1, n, f); fclose(f); }
}

static void service() {
    if (!core) return;
    if (g_flush.exchange(false)) saveSram();
    int op = g_op.exchange(0);
    if (!op) return;
    std::string path; { std::lock_guard<std::mutex> l(g_opMutex); path = g_opPath; }
    if (op == 1) {
        size_t n = r_serialize_size();
        std::vector<uint8_t> b(n);
        if (n && r_serialize(b.data(), n)) {
            FILE *f = fopen(path.c_str(), "wb");
            if (f) { fwrite(b.data(), 1, n, f); fclose(f); }
        }
    } else {
        FILE *f = fopen(path.c_str(), "rb");
        if (!f) return;
        fseek(f, 0, SEEK_END); long n = ftell(f); fseek(f, 0, SEEK_SET);
        std::vector<uint8_t> b(n > 0 ? n : 0);
        if (n > 0) fread(b.data(), 1, n, f);
        fclose(f);
        if (n > 0) r_unserialize(b.data(), b.size());
    }
}

static std::string jstr(JNIEnv *env, jstring s) {
    const char *c = env->GetStringUTFChars(s, nullptr);
    std::string r(c);
    env->ReleaseStringUTFChars(s, c);
    return r;
}

extern "C" {

JNIEXPORT jboolean JNICALL Java_com_example_deltadroid_Native_start(JNIEnv *env, jobject, jstring jcore, jstring jrom, jstring jsave) {
    std::string corePath = jstr(env, jcore), romPath = jstr(env, jrom);
    g_saveDir = jstr(env, jsave);
    core = dlopen(corePath.c_str(), RTLD_NOW);
    if (!core) { LOG("dlopen failed: %s", dlerror()); return JNI_FALSE; }
    LOAD(r_set_environment, "retro_set_environment");
    LOAD(r_set_video_refresh, "retro_set_video_refresh");
    LOAD(r_set_audio_sample, "retro_set_audio_sample");
    LOAD(r_set_audio_sample_batch, "retro_set_audio_sample_batch");
    LOAD(r_set_input_poll, "retro_set_input_poll");
    LOAD(r_set_input_state, "retro_set_input_state");
    LOAD(r_init, "retro_init");
    LOAD(r_deinit, "retro_deinit");
    LOAD(r_get_av_info, "retro_get_system_av_info");
    LOAD(r_load_game, "retro_load_game");
    LOAD(r_unload_game, "retro_unload_game");
    LOAD(r_run, "retro_run");
    LOAD(r_serialize_size, "retro_serialize_size");
    LOAD(r_serialize, "retro_serialize");
    LOAD(r_unserialize, "retro_unserialize");
    LOAD(r_mem_data, "retro_get_memory_data");
    LOAD(r_mem_size, "retro_get_memory_size");
    if (!r_set_environment || !r_init || !r_run || !r_load_game || !r_get_av_info) { LOG("missing symbols"); return JNI_FALSE; }

    r_set_environment(environment);
    r_init();
    r_set_video_refresh(video_refresh);
    r_set_audio_sample(audio_sample);
    r_set_audio_sample_batch(audio_batch);
    r_set_input_poll(input_poll);
    r_set_input_state(input_state);

    FILE *f = fopen(romPath.c_str(), "rb");
    if (!f) { LOG("rom open failed"); return JNI_FALSE; }
    fseek(f, 0, SEEK_END); long n = ftell(f); fseek(f, 0, SEEK_SET);
    g_rom.assign(n, 0);
    fread(g_rom.data(), 1, n, f);
    fclose(f);

    retro_game_info gi{romPath.c_str(), g_rom.data(), g_rom.size(), nullptr};
    if (!r_load_game(&gi)) { LOG("load_game failed"); return JNI_FALSE; }
    retro_system_av_info av{};
    r_get_av_info(&av);
    g_sampleRate = av.timing.sample_rate;
    g_sramPath = g_saveDir + "/" + romPath.substr(romPath.find_last_of('/') + 1) + ".sav";
    loadSram();
    g_keys = 0;
    return JNI_TRUE;
}

JNIEXPORT void JNICALL Java_com_example_deltadroid_Native_run(JNIEnv *, jobject) {
    if (!core) return;
    r_run();
    service();
}
JNIEXPORT void JNICALL Java_com_example_deltadroid_Native_idle(JNIEnv *, jobject) { service(); }

JNIEXPORT void JNICALL Java_com_example_deltadroid_Native_stop(JNIEnv *, jobject) {
    if (!core) return;
    saveSram();
    r_unload_game();
    r_deinit();
    dlclose(core);
    core = nullptr;
}

JNIEXPORT void JNICALL Java_com_example_deltadroid_Native_setSurface(JNIEnv *env, jobject, jobject surface) {
    std::lock_guard<std::mutex> l(g_winMutex);
    if (g_win) { ANativeWindow_release(g_win); g_win = nullptr; }
    if (surface) g_win = ANativeWindow_fromSurface(env, surface);
    g_w = g_h = 0;
}

JNIEXPORT void JNICALL Java_com_example_deltadroid_Native_setKey(JNIEnv *, jobject, jint id, jboolean down) {
    if (id < 0 || id > 15) return;
    if (down) g_keys |= (1u << id); else g_keys &= ~(1u << id);
}

JNIEXPORT jint JNICALL Java_com_example_deltadroid_Native_audioDrain(JNIEnv *env, jobject, jshortArray arr) {
    std::lock_guard<std::mutex> l(g_audMutex);
    jsize cap = env->GetArrayLength(arr);
    jsize n = (jsize)g_aud.size() < cap ? (jsize)g_aud.size() : cap;
    if (n > 0) {
        env->SetShortArrayRegion(arr, 0, n, g_aud.data());
        g_aud.erase(g_aud.begin(), g_aud.begin() + n);
    }
    return n;
}

JNIEXPORT jint JNICALL Java_com_example_deltadroid_Native_sampleRate(JNIEnv *, jobject) { return (jint)g_sampleRate; }

JNIEXPORT void JNICALL Java_com_example_deltadroid_Native_stateOp(JNIEnv *env, jobject, jstring path, jboolean load) {
    { std::lock_guard<std::mutex> l(g_opMutex); g_opPath = jstr(env, path); }
    g_op = load ? 2 : 1;
}

JNIEXPORT void JNICALL Java_com_example_deltadroid_Native_flushSave(JNIEnv *, jobject) { g_flush = true; }

}
